package br.com.indra.jp_capacitacao_2026.controller;

import org.junit.jupiter.api.Test;

public class CategoryControllerTest {
    @Test
    void testCreateCategory() {

    }

    @Test
    void testGetAll() {

    }
}
