package br.com.indra.jp_capacitacao_2026.controller;

import org.junit.jupiter.api.Test;

public class ProductControllerTest {
    @Test
    void testAddStock() {

    }

    @Test
    void testCriarProduct() {

    }

    @Test
    void testGetAll() {

    }

    @Test
    void testRemoveStock() {

    }
}
