package br.com.indra.jp_capacitacao_2026.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.indra.jp_capacitacao_2026.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
    boolean existsByName(String name);
}