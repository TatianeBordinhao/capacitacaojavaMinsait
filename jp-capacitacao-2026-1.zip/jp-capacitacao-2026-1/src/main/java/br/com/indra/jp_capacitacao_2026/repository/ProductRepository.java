package br.com.indra.jp_capacitacao_2026.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.indra.jp_capacitacao_2026.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {

}