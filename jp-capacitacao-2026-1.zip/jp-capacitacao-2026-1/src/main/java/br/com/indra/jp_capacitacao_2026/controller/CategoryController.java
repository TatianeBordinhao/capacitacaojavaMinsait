package br.com.indra.jp_capacitacao_2026.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.indra.jp_capacitacao_2026.model.Category;
import br.com.indra.jp_capacitacao_2026.repository.CategoryRepository;

@RestController
@RequestMapping("/categories")
public class CategoryController {

    @Autowired
    private CategoryRepository categoryRepository;

    @GetMapping
    public List<Category> getAll() {
        return categoryRepository.findAll();
    }

    @PostMapping
    public String createCategory(@RequestBody Category category) {
        if(category.getName() == null || category.getName().isEmpty()) {
            return "Nome obrigatório!";
        }
        if(categoryRepository.existsByName(category.getName())) {
            return "Categoria já existe!";
        }
        categoryRepository.save(category);
        return "Categoria criada!";
    }
}