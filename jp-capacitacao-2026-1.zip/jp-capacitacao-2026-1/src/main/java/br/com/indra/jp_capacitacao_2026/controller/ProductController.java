package br.com.indra.jp_capacitacao_2026.controller;

import br.com.indra.jp_capacitacao_2026.model.Product;
import br.com.indra.jp_capacitacao_2026.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/product")
public class ProductController {

    private final ProductService productService;
    private final ProductRepository productRepository; // injetado

    @PostMapping
    public Product criarProduct(@RequestBody Product product) {
        return productService.criarProduto(product);
    }

    @GetMapping
    public List<Product> getAll() {
        return productService.getAll();
    }

    @PostMapping("/inventory/{productId}/add")
    public String addStock(@PathVariable Long productId, @RequestParam int quantity) {
        Product product = productRepository.findById(productId).orElse(null);
        if (product == null) return "Produto não encontrado!";

        product.setStockQuantity(product.getStockQuantity() + quantity);
        productRepository.save(product);
        return "Estoque adicionado!";
    }

    @PostMapping("/inventory/{productId}/remove")
    public String removeStock(@PathVariable Long productId, @RequestParam int quantity) {
        Product product = productRepository.findById(productId).orElse(null);
        if (product == null) return "Produto não encontrado!";

        if (product.getStockQuantity() < quantity) return "Estoque insuficiente!";

        product.setStockQuantity(product.getStockQuantity() - quantity);
        productRepository.save(product);
        return "Estoque removido!";
    }
}