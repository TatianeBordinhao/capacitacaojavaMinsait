package br.com.indra.jp_capacitacao_2026.service;

import br.com.indra.jp_capacitacao_2026.model.Category;
import br.com.indra.jp_capacitacao_2026.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryService {

    private final CategoryRepository repository;

    public Category salvar(Category category){

        if(category.getName() == null || category.getName().isEmpty()){
            throw new RuntimeException("Nome obrigatório");
        }

        if(repository.existsByName(category.getName())){
            throw new RuntimeException("Categoria já existe");
        }

        return repository.save(category);
    }

    public List<Category> listar(){
        return repository.findAll();
    }
}