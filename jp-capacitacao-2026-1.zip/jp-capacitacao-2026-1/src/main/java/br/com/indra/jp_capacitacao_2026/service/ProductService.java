package br.com.indra.jp_capacitacao_2026.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.com.indra.jp_capacitacao_2026.model.Product;
import br.com.indra.jp_capacitacao_2026.repository.ProductRepository;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    public List<Product> getAll() {
        return productRepository.findAll();
    }

    public Product criarProduto(Product product) {
        return productRepository.save(product);
    }
}